"""
BillLens test suite.
"""
