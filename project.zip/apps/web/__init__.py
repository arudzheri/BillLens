"""
BillLens web applications.
"""